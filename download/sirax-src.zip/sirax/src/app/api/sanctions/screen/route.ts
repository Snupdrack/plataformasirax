import { NextResponse } from 'next/server'
import { screenSanctions } from '@/lib/synkdata'
import { verifyToken, getTokenFromHeaders } from '@/lib/auth'

export async function POST(request: Request) {
  const token = getTokenFromHeaders(request.headers)
  if (!token) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  const payload = verifyToken(token)
  if (!payload) return NextResponse.json({ error: 'Token inválido' }, { status: 401 })

  const { full_name, threshold } = await request.json()
  const result = screenSanctions(full_name, threshold)
  return NextResponse.json(result)
}
